<?php
/**
* Переводы для фраз, встречающихся в PHP и TPL файлах
*/
return array(
    'Страница тестового модуля %name' => 'Page of test module %name',
    '@TITLE@' => 'Title of module in English',
    '@DESCRIPTION@' => 'Description of module in English',
);