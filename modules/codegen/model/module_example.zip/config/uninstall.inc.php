<?php
namespace @NAME@\Config;

/**
* Класс деинсталяции модуля
*/
class Uninstall extends \RS\Module\AbstractUninstall
{}
?>
