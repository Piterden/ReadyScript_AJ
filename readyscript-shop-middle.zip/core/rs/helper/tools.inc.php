<?php
/**
* ReadyScript (http://readyscript.ru)
*
* @copyright Copyright (c) ReadyScript lab. (http://readyscript.ru)
* @license http://readyscript.ru/licenseAgreement/
*/

namespace RS\Helper;

/**
* Класс содержит вспомогательные функции для вызова из любого места кода.
*/
class Tools
{
    /**
    * Оборачивает каждый элемент массива одиночными кавычками + экранирует значения для вставки
    * 
    * @param array $arr
    * @param array $except_key - пропускать элементы по ключу
    */
    public static function arrayQuote($arr, array $except_key = null, $char = "'", $allow_null = false)
    {
        foreach($arr as $k => &$v)
        {
            if ($except_key===null || !in_array($k, $except_key)) {
                if ($allow_null && $v === null) {
                    $v = 'NULL';
                } else {
                    $v = $char.\RS\Db\Adapter::escape($v).$char;
                }
            }
        }
        return $arr;
    }

    /**
    * Подставляет нужную словоформу в зависимости от количественного признака
    * Например: 1 огурец, 2 огурца, 5 огурцов, 24 огурца,....
    * 
    * @param mixed $count - количество предметов
    * @param mixed $first - форма для 1-го предмета, например: (один)'огурец'
    * @param mixed $second - форма для 2-х предметов, например: (два)'огурца'
    * @param mixed $five - форма для 5-ти предметов, например: (пять)'огурцов'
    */
    public static function verb( $count, $first, $second, $five )
    {
        $prepare = abs( intval( $count ) );
        if( $prepare !== 0 ) 
        {
            if( ( $prepare - $prepare % 10 ) / 10 == 1 ) return $five;
            $prepare = $prepare % 10;
            if( $prepare == 1 ) return $first;
            if( $prepare > 1 && $prepare < 5 ) return $second;
            return $five;
        }
        else 
            return $five;
    }
    
    /**
    * @desc Делает из заданного текста тизер не более заданного размера в байтах
    * 
    * @param string Исходный текст
    * @param int Максимальный размер врзвращаемого значения в байтах
    * @param bool исходный и результирующий текст являются html
    * @returns string Строка содержащая обрезанный текст
    */
    static function teaser($text, $size, $html=false)
    {
        $str = (!$html) ? $text : strip_tags($text);
        if(mb_strlen($str)>$size)
        { 
            $str = mb_substr($str,0,$size); 
            if(preg_match('/(.*)[\,|\s|\.]/us',$str, $match)) 
            {
                $str = $match[1];
            }
            $str .= "...";
        }
        return $str;
    }    
    
    /**
    * Отправляет одно письмо на email
    * @deprecated Рекомендуется использовать /RS/Helper/Mailer, вместо данного метода
    * 
    * @param string $subject Тема
    * @param string $from От кого - текст
    * @param string $reply Кому отвечать - текст
    * @param string $from_email От кого - email
    * @param string $reply_email Кому отвечать - email
    * @param string $email email адресата
    * @param string $email_tpl шаблон письма адресату
    * @param array $data массив с переменными
    * @return bool
    */
    public static function sendEmail($subject, $from, $reply, $from_email, $reply_email, $email, $email_tpl, $data)
    {
        $subject = self::mime_header_encode($subject);
        
        $from = empty($from) ? $from_email : self::mime_header_encode($from).'<'.$from_email.'>';
        $replyto = empty($replyto) ? $reply_email : self::mime_header_encode($reply).'<'.$reply_email.'>';
        
        $mail_header="MIME-Version: 1.0"."\r\n".
                     "Content-type: text/html; charset=utf-8"."\r\n".
                     "From: $from"."\r\n".
                     "Reply-To: $replyto"."\r\n";
        
        $view = new \RS\View\Engine();
        $view->assign('data', $data);
        $content = $view->fetch($email_tpl);

        $result = true;
        if (!empty($email)) {
            $emails = explode(',', $email);
            foreach($emails as $one_email) {
                $result = $result && mail(trim($one_email), $subject, $content, $mail_header);
            }
        }
        return $result;
    }
    
    /**
    * @deprecated Рекомендуется использовать /RS/Helper/Mailer, вместо данного метода    
    */
    public static function sendEmailSimple($subject, $email, $email_tpl, $data)
    {
        $system_config = \RS\Config\Loader::getSystemConfig();
        
        self::sendEmail(
            $subject, 
            $system_config->getNoticeFrom(false),
            $system_config->getNoticeReply(false),
            $system_config->getNoticeFrom(true),
            $system_config->getNoticeReply(true),
            $email,
            $email_tpl,
            $data
        );
    }
    
    /**
    * @deprecated Рекомендуется использовать /RS/Helper/Mailer, вместо данного метода    
    */
    public static function mime_header_encode($str, $data_charset = 'utf-8', $send_charset = 'utf-8') 
    {
      if($data_charset != $send_charset) {
        $str = iconv($data_charset, $send_charset, $str);
      }
      return '=?' . $send_charset . '?B?' . base64_encode($str) . '?=';
    }
    
    /**
    * Генерирует пароль определенной длины
    * 
    * @param integer $len длина сгенерированной строки
    * @param array|string $symb допустимые символы для генерации
    * @return string
    */
    public static function generatePassword($len, $symb = null)
    {
        srand();
        if ($symb === null) {
            $symb = array();
            foreach (range('a', 'z') as $letter) $symb[] = $letter;
            foreach (range('A', 'Z') as $letter) $symb[] = $letter;
            foreach (range('0', '9') as $letter) $symb[] = $letter;
        }
        if (is_string($symb)) {
            $symb = str_split($symb);
        }
        
        $pass = '';   
        for ($i=0; $i<$len; $i++) {
            $pass .= $symb[rand(1, count($symb))-1];
        }
        return $pass;
    }
    
    /**
    * Переводит текущую ветку xml в объект SimpleXML
    * @param XMLReader $xml
    * @return SimpleXMLElement
    */
    function xml2simple(\XMLReader $xml)
    {
        $dom = new \DOMDocument();
        $dom->appendChild($xml->expand());
        $xml->next();
        return simplexml_import_dom($dom);
    }    
    
    /**
    * Дополняет строку нужными символами, до требуемой длины
    */
    public static function mb_format($str, $len, $char = ' ')
    {
        if ($len-mb_strlen($str) < 1) return $str;
        return $str.str_repeat($char, $len-mb_strlen($str));
    }
    
    
    /**
    * Заменяет в строе format %k на слово "сегодня, или вчера или 2 дня назад, или дата если больше месяца назад"
    * %v на месяц на русском языке в род. падеже. например: мая, июня
    * 
    * @param mixed $format
    * @param mixed $timestamp
    * @return string format 
    */
    public static function dateExtend($format, $timestamp)
    {
        //%k будет заменяться на слово "сегодня, или вчера или 2 дня назад, или дата если больше месяца назад"
        if (strpos($format, '%k') !==false) {
            $tdate = date('j-n-Y', $timestamp);
            if ($tdate == date('j-n-Y')) $format = str_replace('%k', 'сегодня', $format);
            elseif ($tdate == date('j-n-Y', strtotime('-1 day'))) $format = str_replace('%k', 'вчера', $format);
            elseif ($timestamp > (time() - 60*60*24*31)) 
            {
                $diff = time()-$timestamp;
                $days = ceil($diff/(60*60*24));
                $format = str_replace('%k', $days." ".\RS\Helper\Tools::verb($days,"день","дня","дней")." назад", $format);
            }
            else 
            {
                $format = str_replace('%k', date('d.m.Y', $timestamp), $format);
            }
        }
        
        //%v будет заменен на месяц на русском языке в род. падеже. например: мая, июня
        if (strpos($format, '%v') !== false) {
            $months = array(1 => t('января'), t('февраля'), t('марта'), t('апреля'), t('мая'), t('июня'), 
                            t('июля'), t('августа'), t('сентября'), t('октября'), t('ноября'), t('декабря'));
            $format = str_replace('%v', $months[date('n', $timestamp)], $format);
        }
        
        if (strpos($format, '@date') !== false) {
            $format = str_replace('@date', '%d.%m.%Y', $format);
        }        
        if (strpos($format, '@time') !== false) {
            $format = str_replace('@time', '%H:%M', $format);
        }
        if (strpos($format, '@sec') !== false) {
            $format = str_replace('@sec', '%S', $format);
        }
        
        if (strpos($format, '%datetime') !== false) {
            $format = str_replace('%datetime', '%d.%m.%Y %H:%M:%S', $format);
        }
        
        return $format;
    }
    
    /**
    * Рекурсивно экранирует ключи и значения массива функцией htmlspecialchars
    * 
    * @param array $array исходный массив 
    * @return array возвращает экранированный исходный массив
    */
    public static function escapeArrayRecursive(array $array)
    {
        $result = array();
        foreach($array as $key => $value) {
            $key = htmlspecialchars($key);
            if (is_array($value)) {
                $result[$key] = self::escapeArrayRecursive($value);
            } else {
                $result[$key] = self::toEntityString($value);
            }
        }
        return $result;
    }
    
    /**
    * Переводит спецсимволы строки в entity
    * 
    * @param string $str
    * @return string
    */
    public static function toEntityString($str)
    {
        return htmlspecialchars($str);
    }
    
    /**
    * Проверяет, соответствует ли версия $version требуемой $need
    * 
    * @param string $need - требуемая версия, например 5.3 или 5.03.2525
    * @param string $version - имеющаяся версия, например 5.2.10
    * @return bool Возвращает true, если версия $version больше или равно $need
    */
    public static function compareVersion($need, $version)
    {
        $need_parts = explode('.', $need);
        foreach($need_parts as &$part) {
            $part = sprintf('%05d', $part);
        }
        
        $parts = explode('.', $version);
        $ver_parts = array();
        for($i=0; $i<count($need_parts); $i++) {
            $one = isset($parts[$i]) ? $parts[$i] : 0;
            $ver_parts[] = sprintf('%05d', $one);
        }
        
        $need_str = implode('', $need_parts);
        $ver_str = implode('', $ver_parts);
        
        return strcmp($ver_str, $need_str) >= 0;
    }    
    
    /**
    * Возвращает url, в случае, если он не содержит сторонних доменов.
    * Поддомены в URL разрешаются. В противном случае возвращается $error_url
    * 
    * @param string $url проверяемый адрес 
    * @param string $error_url адрес в случае ошибки
    * 
    * @return string
    */
    public static function cleanOpenRedirect($url, $error_url = '/')
    {
        $my_domain = \RS\Http\Request::commonInstance()->server('HTTP_HOST');
        if (preg_match('/^(http)?(s)?(:)?\/\/([^\/?]+)/' , trim($url), $match) ) {
            //Если обнаружен домен в URL
            if (strpos($match[4], $my_domain) !== false) {
                return $url;
            }
            return $error_url;
        }
        return $url;
    }
    
    /**
    * Переделывает цену из цифр в строки
    * 
    * @param float $price - цена цифрами
    */
    public static function priceToString($price){
       
        
        
       $kopeiki = 0;
       if (mb_stripos($price,'.')!==false){
            $price   = explode('.',$price);
            $kopeiki = $price[1];
            $price   = $price[0];
       }
       if (!$kopeiki){
           $kopeiki = 0;
       }
       $cur = t('[plural:%0:рубль|рубля|рублей]', array($price)); //Плюрал по рублям
       
       # Все варианты написания чисел прописью от 0 до 999 скомпануем в один небольшой массив 
       $m=array( 
            array('ноль'), 
            array('-','один','два','три','четыре','пять','шесть','семь','восемь','девять'), 
            array('десять','одиннадцать','двенадцать','тринадцать','четырнадцать','пятнадцать','шестнадцать','семнадцать','восемнадцать','девятнадцать'), 
            array('-','-','двадцать','тридцать','сорок','пятьдесят','шестьдесят','семьдесят','восемьдесят','девяносто'), 
            array('-','сто','двести','триста','четыреста','пятьсот','шестьсот','семьсот','восемьсот','девятьсот'), 
            array('-','одна','две') 
       ); 
       # Все варианты написания разрядов прописью скомпануем в один небольшой массив 
       $r=array( array('...ллион','','а','ов'), 
            // используется для всех неизвестно больших разрядов 
            array('тысяч','а','и',''), 
            array('миллион','','а','ов'), 
            array('миллиард','','а','ов'), 
            array('триллион','','а','ов'), 
            array('квадриллион','','а','ов'), 
            array('квинтиллион','','а','ов') 
            // ,array(... список можно продолжить 
       ); 
       if($price>0) {
           # Если число ноль, сразу сообщить об этом и выйти $o=array(); 
           # Сюда записываем все получаемые результаты преобразования 
           # Разложим исходное число на несколько трехзначных чисел и каждое полученное такое число обработаем отдельно 
           foreach(array_reverse(str_split(str_pad($price,ceil(strlen($price)/3)*3,'0',STR_PAD_LEFT),3))as$k=>$p){ 
               $o[$k]=array(); 
           # Алгоритм, преобразующий трехзначное число в строку прописью 
           foreach($n=str_split($p)as$kk=>$pp) 
              if(!$pp) continue;
              else 
                  switch($kk){ 
                  case 0:
                      $o[$k][]=$m[4][$pp];
                      break; 
                  case 1:
                     if($pp==1){
                          $o[$k][]=$m[2][$n[2]];
                          break 2;
                      }else
                      $o[$k][]=$m[3][$pp];
                      break; 
                   case 2:
                      if(($k==1)&&($pp<=2))
                          $o[$k][]=$m[5][$pp];
                      else
                         $o[$k][]=$m[1][$pp];
                      break; 
              }
              $p*=1;
              if(!$r[$k]) $r[$k]=reset($r);
               
              # Алгоритм, добавляющий разряд, учитывающий окончание руского языка 
              if($p&&$k)
                   switch(true) { 
                       case preg_match("/^[1]$|^\\d*[0,2-9][1]$/",$p):
                           $o[$k][]=$r[$k][0].$r[$k][1];
                           break; 
                       case preg_match("/^[2-4]$|\\d*[0,2-9][2-4]$/",$p):
                           $o[$k][]=$r[$k][0].$r[$k][2];
                           break; 
                       default:
                          $o[$k][]=$r[$k][0].$r[$k][3];
                       break; 
                   }$o[$k]=implode(' ',$o[$k]); 
              } 
              
          $string_price = implode(' ',array_reverse($o));
            
       }else{
          $string_price = $m[0][0];  
       }  
       $string_kopeiki = t('[plural:%0:копейка|копейки|копеек]', array((int)$kopeiki));
       if ($kopeiki<10){ //Для бухгалтерского вида
           $kopeiki = '0'.$kopeiki; 
       }
           
       return  $string_price." ".$cur." ".$kopeiki." ".$string_kopeiki;
    }
}