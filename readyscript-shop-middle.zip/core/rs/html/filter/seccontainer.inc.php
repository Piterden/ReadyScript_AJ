<?php
/**
* ReadyScript (http://readyscript.ru)
*
* @copyright Copyright (c) ReadyScript lab. (http://readyscript.ru)
* @license http://readyscript.ru/licenseAgreement/
*/

namespace RS\Html\Filter;

/**
* Дополнительный контейнер, содержащий линии с элементами фильтра
*/
class Seccontainer extends  AbstractContainer
{        
    protected
        $tpl = 'system/admin/html_elements/filter/seccontainer.tpl';
}

