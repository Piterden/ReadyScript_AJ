<?php
/**
* Модификатор превращает любое значение в null
*/
function smarty_modifier_devnull($text)
{
    return null;
}  
