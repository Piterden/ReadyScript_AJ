<?php
/**
* ReadyScript (http://readyscript.ru)
*
* @copyright Copyright (c) ReadyScript lab. (http://readyscript.ru)
* @license http://readyscript.ru/licenseAgreement/
*/

namespace Catalog\Controller\Admin;

/**
* Контроллер обслуживает диалог выбора товаров.
* Все методы вызываются Ajax методом
* @ingroup Catalog
*/
class Dialog extends \RS\Controller\Admin\Block
{
    protected
        $id,
        $dirapi,
        $productapi,
        $action_var = 'do';
        
    function init()
    {
        $this->id = $this->url->request('id', TYPE_INTEGER);
        $this->dirapi = new \Catalog\Model\Dirapi();
        $this->productapi = new \Catalog\Model\Api();
    }
    
    /**
    * Возвращает содержимое диалогового окна при первом открытии диалога
    */
    function actionIndex()
    {
        $tree_list = $this->dirapi->getTreeList(0);
        $this->view->assign(array(
            'treeList' => $tree_list,
            'products' => $this->actionGetProducts(0),
            'hideGroupCheckbox' => $this->url->request('hideGroupCheckbox', TYPE_INTEGER, 0)
        ));
        return $this->result
                    ->setHtml( $this->view->fetch('dialog/wrapper.tpl') )
                    ->getOutput();
    }
    
    function actionGetChildCategory()
    {
        $dirlist = $this->dirapi->getTreeList($this->id);
        $this->view->assign(array(
            'hideGroupCheckbox' => $this->url->request('hideGroupCheckbox', TYPE_INTEGER, 0),
            'dirlist' => $dirlist
        ));
        return $this->result
                        ->setHtml( $this->view->fetch('dialog/tree_branch.tpl') )
                        ->getOutput();
    }
    
    function actionGetProducts($category = null)
    {
        $catid = $this->url->request('catid', TYPE_INTEGER);
        $page = $this->url->request('page',TYPE_INTEGER, 1);
        $pageSize = $this->url->request('pageSize', TYPE_INTEGER, 20);
        $filter = $this->url->request('filter', TYPE_ARRAY, array());
        if ($category !== null) $catid = $category;
        if ($catid>0) {
            $this->productapi->setFilter('dir', $catid);
        }
        
        foreach($filter as $key=>$val)
            if ($val != '') {
                switch ($key) 
                {
                    case 'id': $this->productapi->setFilter($key, (int)trim($val));
                        break;
                    case 'title': $this->productapi->setFilter($key, (string)trim($val), '%like%');
                        break;
                    case 'barcode': $this->productapi->setFilter($key, trim((string)$val), '%like%');
                }
            }
        
        if ($page<1) $page = 1;
        if ($pageSize<1) $pageSize = 1;
        
        $total = $this->productapi->getListCount();
        $list = $this->productapi->getList($page, $pageSize);
        $products_dirs = $this->productapi->getProductsDirs($list, true);
        
        $costApi = new \Catalog\Model\CostApi();
        if ( $default_cost_id = $this->getModuleConfig()->default_cost ) {
            $costApi->setOrder("id != '{$default_cost_id}'");
        }
        
        $this->view->assign(array(
            'list' => $list,
            'hideProductCheckbox' => $this->url->request('hideProductCheckbox', TYPE_INTEGER, 0),
            'products_dirs' => $products_dirs,
            'costtypes' => $costApi->getList(),
            'paginator' => array(
                'total' => $total,
                'totalPages' => ceil($total/$pageSize),
                'page' => $page,
                'pageSize' => $pageSize
            )
        ));
        
        if ($category !== null) {
            return $this->view->fetch('dialog/products.tpl');
        } else {
            return $this->result
                        ->setHtml( $this->view->fetch('dialog/products.tpl') )
                        ->getOutput();
        }

    }
}

